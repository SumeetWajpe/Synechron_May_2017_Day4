export interface ICourse{
    name:string;
    price:number;
    location:string;
    duration:string;
    rating:number;
    date:Date;
    description:string;
    votes:number;
}
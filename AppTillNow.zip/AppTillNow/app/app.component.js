"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var AppComponent = (function () {
    function AppComponent() {
        this.name = 'AngularJS';
        this.courseTobeSearched = "";
        this.listOfCourses = [
            {
                name: 'AngularJS',
                duration: '3 Days',
                price: 3000,
                location: 'Hyderabad',
                rating: 3.4,
                votes: 30,
                date: new Date(),
                description: "Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"
            },
            { name: 'ReactJS',
                duration: '3 Days',
                price: 4000,
                votes: 10,
                location: 'Pune',
                rating: 4.589,
                date: new Date(),
                description: "Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"
            },
            { name: 'NodeJS',
                duration: '3 Days',
                votes: 70,
                price: 5000,
                location: 'Goa',
                rating: 5,
                date: new Date(),
                description: "Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"
            }
        ];
        this.imageUrl = "https://i.ytimg.com/vi/hXfigUyeHaY/maxresdefault.jpg";
        this.isSuccess = false;
        this.isDisabled = false;
    }
    AppComponent.prototype.HandleChange = function ($event) {
        // target -> object on which event has fired !
        this.name = $event.target.value;
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            //    template: `
            //    <h1> {{name}} </h1>
            //    <input type="text" [value]="name" 
            //    (input)="HandleChange($event)" />
            // <br/>
            //    <input type="text" [(ngModel)]="name" />
            //    <hr/>
            //    <input type="checkbox" [(ngModel)]="isSuccess" /> Is Success ? 
            // <input type="button" value="Styled(Two Way)" class="btn"
            //   [class.btn-success]="isSuccess" />
            //  `
            //templateUrl:'/app/app.component.html',
            template: "<h1> Training Courses </h1>\n \n\n<!-- <div *ngIf=\"listOfCourses.length == 0\">\n<h1>You dont have any courses yet ! </h1>\n</div>\n\n <div  *ngIf=\"listOfCourses.length != 0\">\n <div *ngFor=\"let c of listOfCourses\">\n    <course [courseName]=\"c\" ></course>\n </div> \n </div> -->\n\n<!-- <input type=\"text\" [(ngModel)]=\"courseTobeSearched\" />\n <div [ngSwitch]=\"courseTobeSearched\">\n        <p *ngSwitchCase=\"'ReactJS'\">React</p>\n        <p *ngSwitchCase=\"'NodeJS'\">Node</p>\n        <p *ngSwitchCase=\"'AngularJS'\">Angular</p>\n        <p *ngSwitchDefault> This course is not available !</p>\n        \n </div> -->\n\n<!-- Search for the courses here : <input type=\"text\" [(ngModel)]=\"courseTobeSearched\" />\n<div [ngSwitch]=\"courseTobeSearched\">\n<div *ngFor=\"let c of listOfCourses\">\n    <div *ngSwitchCase=\"c.name\">   \n      <course [courseName]=\"c\" ></course> \n      </div>      \n </div> \n <p *ngSwitchDefault> This course is not available !</p>\n </div> -->\n\n\n<div *ngFor=\"let c of listOfCourses\">\n      \n    <course [courseName]=\"c\" ></course>\n </div> \n\n "
        }), 
        __metadata('design:paramtypes', [])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map
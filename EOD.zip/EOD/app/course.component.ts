import {Component,Input} from '@angular/core';

@Component({
    selector:'course',    
    template:`  
    
    <div courseHighlight coursecolor="lightblue">
    <likes [counter]="course.votes" (changeLikes)="ChangeLikesHandler($event)"></likes>
                     <h2> {{course.name | uppercase}} </h2>
                      <b> Duration : {{course.duration}} </b> <br/>
                      <b> Date : {{course.date | date:'MM/dd/yyyy'}} </b> <br/>                      
                      <b> Price : {{course.price | currency:'INR':true:'3.0-1'}} </b><br/>
                      <b> Location : {{course.location}} </b><br/>
                      <b> Rating : {{course.rating | number:'1.1-2' }} </b><br/>
                      <b> Likes : {{course.votes  }} </b><br/>                    
                      <b> Description : {{course.description | lowercase | summary:100  }} </b><br/>
                   <!--   <b> JSON : {{ course | json }} </b> -->
                      
                    </div>
                    
    `,

    inputs:["courseName"]  ,  
//  styles:[`
//                 .Course{
//                   border:2px solid red;
//                   border-radius:10px;
//                   background-color:lightgreen;
//                   padding:20px;
//                   margin:20px;
//                 }
 
//   `]
styleUrls:['app/course.component.css']
})
export class CourseComponent{
  @Input("courseName")      course:any={};
  ChangeLikesHandler($event:any){
      this.course.votes = $event; 
  }
}
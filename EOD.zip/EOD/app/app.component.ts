import { Component } from '@angular/core';
import {ICourse} from './ICourse';
@Component({
  selector: 'my-app',
//    template: `
//    <h1> {{name}} </h1>
//    <input type="text" [value]="name" 
//    (input)="HandleChange($event)" />
// <br/>
//    <input type="text" [(ngModel)]="name" />
//    <hr/>
//    <input type="checkbox" [(ngModel)]="isSuccess" /> Is Success ? 
// <input type="button" value="Styled(Two Way)" class="btn"
//   [class.btn-success]="isSuccess" />
//  `
 templateUrl:'/app/app.component.html',
//  template:`<h1> Training Courses </h1>
 

// <!-- <div *ngIf="listOfCourses.length == 0">
// <h1>You dont have any courses yet ! </h1>
// </div>

//  <div  *ngIf="listOfCourses.length != 0">
//  <div *ngFor="let c of listOfCourses">
//     <course [courseName]="c" ></course>
//  </div> 
//  </div> -->

// <!-- <input type="text" [(ngModel)]="courseTobeSearched" />
//  <div [ngSwitch]="courseTobeSearched">
//         <p *ngSwitchCase="'ReactJS'">React</p>
//         <p *ngSwitchCase="'NodeJS'">Node</p>
//         <p *ngSwitchCase="'AngularJS'">Angular</p>
//         <p *ngSwitchDefault> This course is not available !</p>
        
//  </div> -->

// <!-- Search for the courses here : <input type="text" [(ngModel)]="courseTobeSearched" />
// <div [ngSwitch]="courseTobeSearched">
// <div *ngFor="let c of listOfCourses">
//     <div *ngSwitchCase="c.name">   
//       <course [courseName]="c" ></course> 
//       </div>      
//  </div> 
//  <p *ngSwitchDefault> This course is not available !</p>
//  </div> -->


// <form>

// <div *ngFor="let c of listOfCourses">      
//     <course [courseName]="c" ></course>
//  </div> 

//  `,
styles:[`

input.ng-invalid.ng-dirty{
    background-color:pink;
}

input.ng-valid.ng-dirty{
  background-color:lightgreen;
}

input.ng-invalid.ng-pristine{
  background-color:lightyellow;
}

`]
})
export class AppComponent  { 
  name:string = 'AngularJS'; 
 courseTobeSearched:string="";
 
  listOfCourses:any[] = [
    {
      name:'AngularJS',
    duration:'3 Days',
    price:3000,
    location:'Hyderabad',
    rating:3.4,
    votes:30,
    date:new Date(),
    description:"Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"
  }
  ,{name:'ReactJS',
  duration:'3 Days',
  price:4000,
    votes:10,  
  location:'Pune',
  rating:4.589,
  date:new Date(),
    description:"Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"
  
}
  ,{name:'NodeJS',
  duration:'3 Days',
    votes:70,  
  price:5000,
  location:'Goa',
  rating:5,
  date:new Date(),
    description:"Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"
  
}
  ];


  imageUrl:string ="https://i.ytimg.com/vi/hXfigUyeHaY/maxresdefault.jpg";
  isSuccess:boolean = false;
  isDisabled:boolean=false;
  newCourse:any={};
  HandleChange($event:any){
    // target -> object on which event has fired !
      this.name = $event.target.value;
  }

  onFormSubmit(formPassed:any,$event:any){
        $event.preventDefault();
       // console.log(formPassed.valid);

let newCourseToBeAdded = {
  name:this.newCourse.name,
  price:this.newCourse.price,
  location:this.newCourse.location,
  date:new Date(),
  rating:this.newCourse.rating  
}
       this.listOfCourses.push(newCourseToBeAdded);
       formPassed.reset();
  }

  }

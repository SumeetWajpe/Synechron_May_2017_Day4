"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var CourseComponent = (function () {
    function CourseComponent() {
        this.course = {};
    }
    CourseComponent.prototype.ChangeLikesHandler = function ($event) {
        this.course.votes = $event;
    };
    __decorate([
        core_1.Input("courseName"), 
        __metadata('design:type', Object)
    ], CourseComponent.prototype, "course", void 0);
    CourseComponent = __decorate([
        core_1.Component({
            selector: 'course',
            template: "  \n    \n    <div courseHighlight coursecolor=\"lightblue\">\n    <likes [counter]=\"course.votes\" (changeLikes)=\"ChangeLikesHandler($event)\"></likes>\n                     <h2> {{course.name | uppercase}} </h2>\n                      <b> Duration : {{course.duration}} </b> <br/>\n                      <b> Date : {{course.date | date:'MM/dd/yyyy'}} </b> <br/>                      \n                      <b> Price : {{course.price | currency:'INR':true:'3.0-1'}} </b><br/>\n                      <b> Location : {{course.location}} </b><br/>\n                      <b> Rating : {{course.rating | number:'1.1-2' }} </b><br/>\n                      <b> Likes : {{course.votes  }} </b><br/>                    \n                      <b> Description : {{course.description | lowercase | summary:100  }} </b><br/>\n                   <!--   <b> JSON : {{ course | json }} </b> -->\n                      \n                    </div>\n                    \n    ",
            inputs: ["courseName"],
            //  styles:[`
            //                 .Course{
            //                   border:2px solid red;
            //                   border-radius:10px;
            //                   background-color:lightgreen;
            //                   padding:20px;
            //                   margin:20px;
            //                 }
            //   `]
            styleUrls: ['app/course.component.css']
        }), 
        __metadata('design:paramtypes', [])
    ], CourseComponent);
    return CourseComponent;
}());
exports.CourseComponent = CourseComponent;
//# sourceMappingURL=course.component.js.map
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var AppComponent = (function () {
    function AppComponent() {
        this.name = 'AngularJS';
        this.courseTobeSearched = "";
        this.listOfCourses = [
            {
                name: 'AngularJS',
                duration: '3 Days',
                price: 3000,
                location: 'Hyderabad',
                rating: 3.4,
                votes: 30,
                date: new Date(),
                description: "Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"
            },
            { name: 'ReactJS',
                duration: '3 Days',
                price: 4000,
                votes: 10,
                location: 'Pune',
                rating: 4.589,
                date: new Date(),
                description: "Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"
            },
            { name: 'NodeJS',
                duration: '3 Days',
                votes: 70,
                price: 5000,
                location: 'Goa',
                rating: 5,
                date: new Date(),
                description: "Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"
            }
        ];
        this.imageUrl = "https://i.ytimg.com/vi/hXfigUyeHaY/maxresdefault.jpg";
        this.isSuccess = false;
        this.isDisabled = false;
        this.newCourse = {};
    }
    AppComponent.prototype.HandleChange = function ($event) {
        // target -> object on which event has fired !
        this.name = $event.target.value;
    };
    AppComponent.prototype.onFormSubmit = function (formPassed, $event) {
        $event.preventDefault();
        // console.log(formPassed.valid);
        var newCourseToBeAdded = {
            name: this.newCourse.name,
            price: this.newCourse.price,
            location: this.newCourse.location,
            date: new Date(),
            rating: this.newCourse.rating
        };
        this.listOfCourses.push(newCourseToBeAdded);
        formPassed.reset();
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            //    template: `
            //    <h1> {{name}} </h1>
            //    <input type="text" [value]="name" 
            //    (input)="HandleChange($event)" />
            // <br/>
            //    <input type="text" [(ngModel)]="name" />
            //    <hr/>
            //    <input type="checkbox" [(ngModel)]="isSuccess" /> Is Success ? 
            // <input type="button" value="Styled(Two Way)" class="btn"
            //   [class.btn-success]="isSuccess" />
            //  `
            templateUrl: '/app/app.component.html',
            //  template:`<h1> Training Courses </h1>
            // <!-- <div *ngIf="listOfCourses.length == 0">
            // <h1>You dont have any courses yet ! </h1>
            // </div>
            //  <div  *ngIf="listOfCourses.length != 0">
            //  <div *ngFor="let c of listOfCourses">
            //     <course [courseName]="c" ></course>
            //  </div> 
            //  </div> -->
            // <!-- <input type="text" [(ngModel)]="courseTobeSearched" />
            //  <div [ngSwitch]="courseTobeSearched">
            //         <p *ngSwitchCase="'ReactJS'">React</p>
            //         <p *ngSwitchCase="'NodeJS'">Node</p>
            //         <p *ngSwitchCase="'AngularJS'">Angular</p>
            //         <p *ngSwitchDefault> This course is not available !</p>
            //  </div> -->
            // <!-- Search for the courses here : <input type="text" [(ngModel)]="courseTobeSearched" />
            // <div [ngSwitch]="courseTobeSearched">
            // <div *ngFor="let c of listOfCourses">
            //     <div *ngSwitchCase="c.name">   
            //       <course [courseName]="c" ></course> 
            //       </div>      
            //  </div> 
            //  <p *ngSwitchDefault> This course is not available !</p>
            //  </div> -->
            // <form>
            // <div *ngFor="let c of listOfCourses">      
            //     <course [courseName]="c" ></course>
            //  </div> 
            //  `,
            styles: ["\n\ninput.ng-invalid.ng-dirty{\n    background-color:pink;\n}\n\ninput.ng-valid.ng-dirty{\n  background-color:lightgreen;\n}\n\ninput.ng-invalid.ng-pristine{\n  background-color:lightyellow;\n}\n\n"]
        }), 
        __metadata('design:paramtypes', [])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map